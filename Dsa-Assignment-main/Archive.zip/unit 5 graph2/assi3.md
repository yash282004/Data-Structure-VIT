## ASSIGNMENT 3
*Title:*

Write a Program to implement Prim’s algorithm to find minimum
spanning tree of a user defined graph. Use Adjacency List to represent a graph.

## Author:

**Pralhad Shivaji Chape**

## Aim:

To write a C++ program to find the Minimum Spanning Tree (MST) of a user-defined graph using Prim’s Algorithm with an Adjacency List representation.

## Problem Statement:

- Develop a C++ program that:

1. Accepts vertices and weighted edges from the user

2. Stores the graph in Adjacency List form

3. Applies Prim’s Algorithm to compute MST

4. Displays the edges and minimum total cost

## Theory
- Graph (Weighted Undirected)

- A graph where each edge carries a weight.

- Adjacency List

- A list of linked or vector-based lists representing each node and its neighbors.

- Efficient for sparse graphs.

- Prim’s Algorithm

- Greedy algorithm for finding MST

- Starts from any single node

- Repeatedly selects the minimum weight edge connecting a visited node to an unvisited node

## Algorithm: Prim’s Algorithm

1. Start

2. Read total vertices V_psc

3. Create adjacency list adj_psc

4. Take edges (u_psc, v_psc, w_psc)

5. Select start node

6. Push all its adjacent edges into priority queue

7. While queue is not empty:

8. Pick smallest edge

9. If destination is unvisited, add to MST

10. Push its edges

11. Repeat until MST has (V_psc - 1) edges

12. Display MST and total cost

13. Stop

## C++ Program 
```cpp
#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Graph_psc {
private:
    int V_psc;
    vector<vector<pair<int, int>>> adj_psc;  

public:
    Graph_psc(int vertices_psc) {
        V_psc = vertices_psc;
        adj_psc.resize(V_psc);
    }

    void addEdge_psc(int u_psc, int v_psc, int w_psc) {
        adj_psc[u_psc].push_back({v_psc, w_psc});
        adj_psc[v_psc].push_back({u_psc, w_psc});  
    }

    void prim_psc(int start_psc) {
        vector<bool> visited_psc(V_psc, false);
        priority_queue<pair<int, pair<int, int>>, 
                       vector<pair<int, pair<int, int>>>,
                       greater<pair<int, pair<int, int>>>> pq_psc;

        visited_psc[start_psc] = true;

        for (auto edge_psc : adj_psc[start_psc]) {
            pq_psc.push({edge_psc.second, {start_psc, edge_psc.first}});
        }

        int mst_cost_psc = 0;

        cout << "\nEdges in MST:\n";

        while (!pq_psc.empty()) {
            auto top_psc = pq_psc.top();
            pq_psc.pop();

            int weight_psc = top_psc.first;
            int u_psc = top_psc.second.first;
            int v_psc = top_psc.second.second;

            if (visited_psc[v_psc])
                continue;

            visited_psc[v_psc] = true;
            cout << u_psc << " -- " << v_psc << "  (Weight: " << weight_psc << ")\n";
            mst_cost_psc += weight_psc;

            for (auto next_psc : adj_psc[v_psc]) {
                if (!visited_psc[next_psc.first]) {
                    pq_psc.push({next_psc.second, {v_psc, next_psc.first}});
                }
            }
        }

        cout << "\nTotal cost of MST: " << mst_cost_psc << endl;
    }
};

int main() {
    int vertices_psc, edges_psc;

    cout << "Enter number of vertices: ";
    cin >> vertices_psc;

    Graph_psc g_psc(vertices_psc);

    cout << "Enter number of edges: ";
    cin >> edges_psc;

    cout << "\nEnter edges in format: u v w\n";
    for (int i_psc = 0; i_psc < edges_psc; i_psc++) {
        int u_psc, v_psc, w_psc;
        cin >> u_psc >> v_psc >> w_psc;
        g_psc.addEdge_psc(u_psc, v_psc, w_psc);
    }

    int start_psc;
    cout << "Enter starting vertex for Prims algorithm: ";
    cin >> start_psc;

    g_psc.prim_psc(start_psc);

    return 0;
}
```
## Sample Output
```
Enter number of vertices: 5
Enter number of edges: 6
Enter edges (u v w):
0 1 2
0 3 6
1 2 3
1 3 8
1 4 5
2 4 7

Enter starting vertex: 0

Edges in MST:
0 -- 1  (Weight: 2)
1 -- 2  (Weight: 3)
1 -- 4  (Weight: 5)
0 -- 3  (Weight: 6)

Total cost of MST: 16
```
## Conclusion

The program successfully implements Prim’s Algorithm using an Adjacency List, generating the Minimum Spanning Tree and calculating its total cost. The adjacency list representation ensures efficient storage and traversal of sparse graphs.