## Assignment 4

*Title*
Write a Program to implement Kruskal’s algorithm to find the minimum spanning tree of a user defined graph. Use Adjacency List to represent a graph.

## Author:

**Pralhad Shivaji Chape**

##  AIM

To write a C++ program to create a user-defined graph using adjacency list representation and apply Kruskal’s algorithm to find the Minimum Spanning Tree (MST).

## THEORY
- Graph

- A graph G(V, E) consists of a set of vertices and edges.

- Minimum Spanning Tree (MST)

- An MST of a connected weighted graph is a subset of edges that:

- connects all vertices,

- has no cycles,

- and has minimum total cost.

- Kruskal’s Algorithm (Greedy Algorithm)

- Kruskal's algorithm sorts all edges in ascending order of weight and adds them to the MST if they do not form a cycle.

## KRUSKAL’S ALGORITHM

- Sort all edges in non-decreasing order of weight.

- Initialize MST as empty.

- For each edge (u, v):

- If including it doesn't form a cycle → include it in MST.

- Use Disjoint Set / Union-Find to detect cycles.

- Repeat until MST contains (V−1) edges.

##  ADJACENCY LIST REPRESENTATION

- We store graph edges using:

- vector<pair<int, int>> adj[V];

- Each entry contains:
→ (neighbor, weight)

- We also maintain a list of edges:

- vector<Edge> edges;

##  C++ PROGRAM 
```cpp
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Edge {
    int u, v, w;
};


bool compareEdges(Edge a, Edge b) {
    return a.w < b.w;
}

vector<int> parent, Rank;

int findSet(int v) {
    if (v == parent[v])
        return v;
    return parent[v] = findSet(parent[v]);   
}

void unionSet(int u, int v) {
    u = findSet(u);
    v = findSet(v);

    if (u != v) {
        if (Rank[u] < Rank[v])
            parent[u] = v;
        else if (Rank[u] > Rank[v])
            parent[v] = u;
        else {
            parent[v] = u;
            Rank[u]++;
        }
    }
}

int main() {
    int V, E;
    cout << "Enter number of vertices: ";
    cin >> V;

    cout << "Enter number of edges: ";
    cin >> E;

    vector<vector<pair<int, int>>> adj(V);
    vector<Edge> edges;

    cout << "\nEnter edges in format: u v weight\n";
    for (int i = 0; i < E; i++) {
        int u, v, w;
        cin >> u >> v >> w;

        adj[u].push_back({v, w});
        adj[v].push_back({u, w});

        edges.push_back({u, v, w});
    }

    parent.resize(V);
    Rank.resize(V, 0);

    for (int i = 0; i < V; i++)
        parent[i] = i;

    sort(edges.begin(), edges.end(), compareEdges);

    vector<Edge> mst;
    int totalCost = 0;

    for (auto &e : edges) {
        if (findSet(e.u) != findSet(e.v)) {
            mst.push_back(e);
            totalCost += e.w;
            unionSet(e.u, e.v);
        }
    }

    cout << "\nMinimum Spanning Tree using Kruskal's Algorithm:\n";
    for (auto &e : mst) {
        cout << e.u << " -- " << e.v << "  weight: " << e.w << endl;
    }

    cout << "Total cost of MST: " << totalCost << endl;

    return 0;
}
```
## SAMPLE INPUT
```
Enter number of vertices: 4
Enter number of edges: 5
0 1 10
0 2 6
0 3 5
1 3 15
2 3 4

SAMPLE OUTPUT
2 -- 3  weight: 4
0 -- 3  weight: 5
0 -- 1  weight: 10
Total cost of MST: 19
```
##  CONCLUSION

- Kruskal’s algorithm efficiently finds the Minimum Spanning Tree (MST) by using:

- - edge-sorting,

- - greedy strategy,

- - and Disjoint Set (Union-Find) to avoid cycles.