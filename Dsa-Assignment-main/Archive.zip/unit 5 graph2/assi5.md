## Assignment 5

*Title*

Write a Program to implement Dijkstra’s algorithm to find shortest distance between two nodes of a user defined graph. Use Adjacency List to represent a graph.

## Author:

**Pralhad Shivaji Chape**

## Aim

To write a program to implement Dijkstra’s algorithm to find the shortest distance between two nodes of a user-defined graph using an Adjacency List representation.

## Theory
- Dijkstra’s Algorithm

- - Dijkstra’s Algorithm is a greedy algorithm used to find the shortest path from a source vertex to all other vertices in a graph with non-negative edge weights.

- Steps

1. Set all distances to infinity except the source.

2. Mark all nodes unvisited.

3. Pick the unvisited node with minimum distance.

4. Update distances of its adjacent nodes.

5. Mark the current node as visited.

6. Repeat until all nodes are visited or destination is reached.

- Adjacency List

A graph representation where each node stores a list of its connected neighbors and edge weights.
Efficient for sparse graphs.

## C++ Program 
```cpp
#include <iostream>
#include <vector>
#include <queue>
#include <climits>    

using namespace std;

class Graph {
private:
    int V; 
    vector<vector<pair<int, int>>> adj; 

public:
    Graph(int vertices) {
        V = vertices;
        adj.resize(V);
    }

    void addEdge(int u, int v, int w) {
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});  
    }

    void dijkstra(int src, int dest) {
        vector<int> dist(V, INT_MAX);
        dist[src] = 0;

        priority_queue<pair<int, int>, vector<pair<int, int>>,
                       greater<pair<int, int>>> pq;

        pq.push({0, src});

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();

            for (auto edge : adj[u]) {
                int v = edge.first;
                int weight = edge.second;

                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.push({dist[v], v});
                }
            }
        }

        if (dist[dest] == INT_MAX)
            cout << "No path exists between " << src << " and " << dest << endl;
        else
            cout << "Shortest distance from " << src 
                 << " to " << dest << " = " << dist[dest] << endl;
    }
};

int main() {
    int V, E;
    cout << "Enter number of vertices: ";
    cin >> V;

    Graph g(V);

    cout << "Enter number of edges: ";
    cin >> E;

    cout << "Enter edges (u v w):" << endl;
    for (int i = 0; i < E; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        g.addEdge(u, v, w);
    }

    int src, dest;
    cout << "Enter source and destination: ";
    cin >> src >> dest;

    g.dijkstra(src, dest);

    return 0;
}

```

##  Input / Output
```
Enter number of vertices: 5
Enter number of edges: 6
Enter edges (u v w):
0 1 2
0 2 4
1 2 1
1 3 7
2 4 3
3 4 2
Enter source node: 0
Enter destination node: 3

Shortest Distance from 0 to 3 = 8
Path: 0 -> 1 -> 2 -> 4 -> 3

```
## Conclusion

The program successfully implements Dijkstra’s Algorithm to compute the shortest distance between two nodes of a user-defined graph using Adjacency List representation.
This approach is efficient with time complexity O(E log V).