## ASSIGNMENT 1
*Title*:*

Write a Program to implement Kruskal’s algorithm to find the minimum spanning tree of a user defined graph. Use Adjacency Matrix to represent a graph.

**Author:**

**Pralhad Shivaji Chape**

## Aim

To write a C++ program using an Adjacency Matrix to represent a graph and implement Kruskal’s Algorithm to find the Minimum Spanning Tree (MST).

## Problem Statement

Design and develop a program in C++ to:

- Accept number of vertices and edges.

- Store the graph using an Adjacency Matrix.

- Apply Kruskal’s Algorithm to find the Minimum Spanning Tree (MST).

- Display the selected edges and the total minimum cost.

## Theory
- Graph

- - A graph consists of vertices connected by weighted edges.

- Minimum Spanning Tree (MST)

- - A spanning tree is a subset of edges that connects all vertices with minimum total cost and no cycles.

## Kruskal’s Algorithm

- Greedy algorithm

- Works by selecting the minimum weight edge that does not form a cycle

- Uses Disjoint Set / Union-Find for cycle detection

- Best for sparse graphs

## Adjacency Matrix

A 2D array where:

- matrix[i][j] = weight if edge exists

- matrix[i][j] = 0 or INF if no edge

## Algorithm
- Algorithm: Kruskal’s MST

1. Start

2. Read number of vertices V_psc

3. Read adjacency matrix graph_psc[][]

4. Create edge list from matrix

5. Sort edges by weight

6. Initialize disjoint sets

7. Traverse sorted edges

8. If adding the edge does not create cycle → include in MST

9. Repeat until V_psc - 1 edges selected

10. Print edges and total minimum cost

11. Stop

## C++ Program 
```cpp
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Edge_psc {
public:
    int src_psc, dest_psc, wt_psc;
};

class Graph_psc {
private:
    int V_psc;
    vector<Edge_psc> edges_psc;

    int findSet_psc(vector<int> &parent_psc, int v_psc) {
        if (parent_psc[v_psc] == v_psc)
            return v_psc;
        return parent_psc[v_psc] = findSet_psc(parent_psc, parent_psc[v_psc]);
    }

    void unionSet_psc(vector<int> &parent_psc, vector<int> &rank_psc, int a_psc, int b_psc) {
        a_psc = findSet_psc(parent_psc, a_psc);
        b_psc = findSet_psc(parent_psc, b_psc);

        if (a_psc != b_psc) {
            if (rank_psc[a_psc] < rank_psc[b_psc])
                swap(a_psc, b_psc);
            parent_psc[b_psc] = a_psc;
            if (rank_psc[a_psc] == rank_psc[b_psc])
                rank_psc[a_psc]++;
        }
    }

public:
    Graph_psc(int vertices_psc) {
        V_psc = vertices_psc;
    }

    void inputMatrix_psc() {
        cout << "\nEnter the adjacency matrix (0 for no edge):\n";
        for (int i_psc = 0; i_psc < V_psc; i_psc++) {
            for (int j_psc = 0; j_psc < V_psc; j_psc++) {
                int wt_psc;
                cin >> wt_psc;
                if (wt_psc != 0 && i_psc != j_psc) {
                    Edge_psc e_psc;
                    e_psc.src_psc = i_psc;
                    e_psc.dest_psc = j_psc;
                    e_psc.wt_psc = wt_psc;
                    edges_psc.push_back(e_psc);
                }
            }
        }
    }

    void kruskalMST_psc() {
        sort(edges_psc.begin(), edges_psc.end(), 
             [](Edge_psc a_psc, Edge_psc b_psc) {
                 return a_psc.wt_psc < b_psc.wt_psc;
             });

        vector<int> parent_psc(V_psc);
        vector<int> rank_psc(V_psc, 0);

        for (int i_psc = 0; i_psc < V_psc; i_psc++)
            parent_psc[i_psc] = i_psc;

        int totalCost_psc = 0;

        cout << "\nEdges in Minimum Spanning Tree:\n";

        int edgeCount_psc = 0;

        for (auto e_psc : edges_psc) {
            int setU_psc = findSet_psc(parent_psc, e_psc.src_psc);
            int setV_psc = findSet_psc(parent_psc, e_psc.dest_psc);

            if (setU_psc != setV_psc) {
                cout << e_psc.src_psc << " -- " << e_psc.dest_psc 
                     << "  (Weight: " << e_psc.wt_psc << ")\n";

                totalCost_psc += e_psc.wt_psc;
                unionSet_psc(parent_psc, rank_psc, setU_psc, setV_psc);
                edgeCount_psc++;

                if (edgeCount_psc == V_psc - 1)
                    break;
            }
        }

        cout << "\nTotal Minimum Cost: " << totalCost_psc << endl;
    }
};

int main() {
    int v_psc;
    cout << "Enter number of vertices: ";
    cin >> v_psc;

    Graph_psc g_psc(v_psc);
    g_psc.inputMatrix_psc();
    g_psc.kruskalMST_psc();

    return 0;
}
```
## Sample Output
```
Enter number of vertices: 4
Enter the adjacency matrix:
0 4 6 0
4 0 6 3
6 6 0 2
0 3 2 0

Edges in Minimum Spanning Tree:
2 -- 3  (Weight: 2)
1 -- 3  (Weight: 3)
0 -- 1  (Weight: 4)

Total Minimum Cost: 9
```
## Conclusion

Kruskal’s algorithm was successfully implemented using an adjacency matrix.
The program finds the Minimum Spanning Tree (MST) by selecting the least-cost edges without forming cycles, demonstrating efficient greedy algorithm behavior.