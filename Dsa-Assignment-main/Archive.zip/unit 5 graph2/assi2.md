## ASSIGNMENT 2
*Title:*

Write a Program to implement Dijkstra’s algorithm to find shortest distance between two nodes of a user defined graph. Use Adjacency Matrix to represent a graph.

## Author:

**Pralhad Shivaji Chape**

## Aim:

To write a C++ program to find the shortest distance between two nodes of a user-defined graph using Dijkstra’s Algorithm with an Adjacency Matrix representation.

## Problem Statement:

- Develop a C++ program that:

1.  number of vertices and weighted edges.

2. Stores the graph in Adjacency Matrix form.

3. Applies Dijkstra’s Algorithm to compute shortest path from a source node to all other nodes.

4. Displays shortest distance from source to destination node.

## Algorithm: Dijkstra’s Algorithm

1. Start

2. Read total vertices V_psc

3. Read adjacency matrix graph_psc[][]

4. Take source vertex src_psc

5. Initialize distance array with infinity

6. Set distance of source = 0

7. Mark all nodes unvisited

8. Repeat for V_psc – 1 times:

9. Select the unvisited node having minimum distance

10. Update distances of its adjacent nodes

11. Display shortest distances

12. Stop

## C++ Program
```c
#include <iostream>
#include <vector>
using namespace std;

#define INF 999999

class Graph_psc {
private:
    int V_psc;
    vector<vector<int>> adj_psc;

public:
    Graph_psc(int vertices_psc) {
        V_psc = vertices_psc;
        adj_psc.resize(V_psc, vector<int>(V_psc));
    }

    void inputMatrix_psc() {
        cout << "\nEnter adjacency matrix (0 for no edge):\n";
        for (int i_psc = 0; i_psc < V_psc; i_psc++) {
            for (int j_psc = 0; j_psc < V_psc; j_psc++) {
                cin >> adj_psc[i_psc][j_psc];
                if (i_psc != j_psc && adj_psc[i_psc][j_psc] == 0)
                    adj_psc[i_psc][j_psc] = INF;
            }
        }
    }

    int getMinDistanceIndex_psc(vector<int> &dist_psc, vector<bool> &visited_psc) {
        int min_psc = INF, index_psc = -1;

        for (int i_psc = 0; i_psc < V_psc; i_psc++) {
            if (!visited_psc[i_psc] && dist_psc[i_psc] <= min_psc) {
                min_psc = dist_psc[i_psc];
                index_psc = i_psc;
            }
        }
        return index_psc;
    }

    void dijkstra_psc(int src_psc) {
        vector<int> dist_psc(V_psc, INF);
        vector<bool> visited_psc(V_psc, false);

        dist_psc[src_psc] = 0;

        for (int count_psc = 0; count_psc < V_psc - 1; count_psc++) {
            int u_psc = getMinDistanceIndex_psc(dist_psc, visited_psc);
            visited_psc[u_psc] = true;

            for (int v_psc = 0; v_psc < V_psc; v_psc++) {
                if (!visited_psc[v_psc] && adj_psc[u_psc][v_psc] != INF &&
                    dist_psc[u_psc] + adj_psc[u_psc][v_psc] < dist_psc[v_psc]) {
                    dist_psc[v_psc] = dist_psc[u_psc] + adj_psc[u_psc][v_psc];
                }
            }
        }

        cout << "\nShortest Distances From Source " << src_psc << ":\n";
        for (int i_psc = 0; i_psc < V_psc; i_psc++) {
            cout << "To Node " << i_psc << " = " << dist_psc[i_psc] << endl;
        }
    }
};

int main() {
    int vertices_psc, src_psc;

    cout << "Enter number of vertices: ";
    cin >> vertices_psc;

    Graph_psc g_psc(vertices_psc);

    g_psc.inputMatrix_psc();

    cout << "Enter source vertex: ";
    cin >> src_psc;

    g_psc.dijkstra_psc(src_psc);

    return 0;
}
```
##  Output
```
Enter number of vertices: 5

Enter adjacency matrix:
0 10 0 5 0
0 0 1 2 0
0 0 0 0 4
0 3 9 0 2
7 0 6 0 0

Enter source vertex: 0

Shortest Distances From Source 0:
To Node 0 = 0
To Node 1 = 8
To Node 2 = 9
To Node 3 = 5
To Node 4 = 7
```
## Conclusion

The program successfully implements Dijkstra’s Algorithm using an Adjacency Matrix.
It efficiently computes the minimum shortest path from a given source node to all other nodes using a greedy approach.