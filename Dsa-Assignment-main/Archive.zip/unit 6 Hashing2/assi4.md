## Assignment 4
*Title:*
WAP to simulate student databases as a hash table. a student database management system using hashing techniques to allow efficient insertion, search, and deletion of student records.

## Author:

**Pralhad Shivaji Chape**

## Aim:

To write a C++ program that simulates a student database using hashing for efficient insertion, search, and deletion of student records.

## Problem Statement:

- Create a Student Database Management System using a hash table.
- Each student record contains:

- Roll Number

- Name

- Marks

- Use hashing to store records efficiently. Implement:

- Insertion

- Searching

- Deletion

- Use MOD hashing function with Linear Probing for collision resolution.

- Hash Function Used:
- index = rollNo % tableSize

## Algorithm:
1. Start the program
2. Define a structure Student

- Containing roll number, name, marks, and a flag indicating empty/filled/deleted.

3. Create a Hash Table

- Initialize all positions as empty.

4. For Insertion

- Compute index = rollNo % size

- If empty → insert

- If occupied → linear probe to next index

- Stop when record is inserted

5. For Searching

- Compute index

- Check the slot

- If roll number matches → student found

- Else probe until found or all checked

6. For Deletion

- Search for roll number

- If found → mark the slot as deleted

7. Display records
8. Stop

##  C++ Program
```c++
#include <iostream>
#include <string>
using namespace std;

struct Student {
    int roll;
    string name;
    int marks;
    bool occupied;
    bool deleted;

    Student() {
        roll = 0;
        name = "";
        marks = 0;
        occupied = false;
        deleted = false;
    }
};

class HashTable {
private:
    int size;
    Student* table;

public:
    HashTable(int s) {
        size = s;
        table = new Student[size];
    }

    int hashFunction(int roll) {
        return roll % size;
    }

    void insertStudent(int roll, string name, int marks) {
        int index = hashFunction(roll);

        for (int i = 0; i < size; i++) {
            int newIndex = (index + i) % size;

            if (!table[newIndex].occupied || table[newIndex].deleted) {
                table[newIndex].roll = roll;
                table[newIndex].name = name;
                table[newIndex].marks = marks;
                table[newIndex].occupied = true;
                table[newIndex].deleted = false;

                cout << "Student inserted successfully!\n";
                return;
            }
        }

        cout << "Hash Table is Full! Cannot Insert.\n";
    }

    void searchStudent(int roll) {
        int index = hashFunction(roll);

        for (int i = 0; i < size; i++) {
            int newIndex = (index + i) % size;

            if (!table[newIndex].occupied && !table[newIndex].deleted)
                break;

            if (table[newIndex].occupied && !table[newIndex].deleted &&
                table[newIndex].roll == roll) 
            {
                cout << "\nStudent Found:\n";
                cout << "Roll No: " << table[newIndex].roll << endl;
                cout << "Name: " << table[newIndex].name << endl;
                cout << "Marks: " << table[newIndex].marks << endl;
                return;
            }
        }

        cout << "Student Not Found!\n";
    }

    void deleteStudent(int roll) {
        int index = hashFunction(roll);

        for (int i = 0; i < size; i++) {
            int newIndex = (index + i) % size;

            if (table[newIndex].occupied && !table[newIndex].deleted &&
                table[newIndex].roll == roll) 
            {
                table[newIndex].deleted = true;
                table[newIndex].occupied = false;

                cout << "Student deleted successfully!\n";
                return;
            }
        }

        cout << "Student Not Found!\n";
    }

    void display() {
        cout << "\n--- Student Hash Table ---\n";
        for (int i = 0; i < size; i++) {
            cout << i << ": ";
            if (table[i].occupied) {
                cout << "Roll: " << table[i].roll
                     << ", Name: " << table[i].name
                     << ", Marks: " << table[i].marks;
            } else {
                cout << "Empty";
            }
            cout << endl;
        }
    }
};

int main() {
    cout << "Student Database Using Hash Table\n";
    cout << "Author: Pralhad Shivaji Chape\n\n";

    int size;
    cout << "Enter Hash Table Size: ";
    cin >> size;

    HashTable ht(size);

    int choice, roll, marks;
    string name;

    do {
        cout << "\n1. Insert Student\n2. Search Student\n3. Delete Student\n4. Display\n5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Roll Number: ";
                cin >> roll;
                cout << "Enter Name: ";
                cin >> name;
                cout << "Enter Marks: ";
                cin >> marks;
                ht.insertStudent(roll, name, marks);
                break;

            case 2:
                cout << "Enter Roll Number to Search: ";
                cin >> roll;
                ht.searchStudent(roll);
                break;

            case 3:
                cout << "Enter Roll Number to Delete: ";
                cin >> roll;
                ht.deleteStudent(roll);
                break;

            case 4:
                ht.display();
                break;

            case 5:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }
    } while (choice != 5);

    return 0;
}
```
## Sample Output
```
Student Database Using Hash Table
Author: Pralhad Shivaji Chape

Enter Hash Table Size: 10

1. Insert Student
2. Search Student
3. Delete Student
4. Display
5. Exit
Enter your choice: 1
Enter Roll Number: 23
Enter Name: Raj
Enter Marks: 85
Student inserted successfully!

Enter your choice: 1
Enter Roll Number: 44
Enter Name: Amit
Enter Marks: 76
Student inserted successfully!

Enter your choice: 2
Enter Roll Number to Search: 23

Student Found:
Roll No: 23
Name: Raj
Marks: 85

Enter your choice: 4
--- Student Hash Table ---
0: Empty
1: Roll: 23, Name: Raj, Marks: 85
4: Roll: 44, Name: Amit, Marks: 76
Rest Empty...
```
## Explanation

- Hash table stores student records using roll number as key.

-  are resolved using linear probing.

-  probes sequentially until student is found.

- Deletion marks the slot as deleted but keeps probing functional.

- Hash table ensures fast access and efficient data management.