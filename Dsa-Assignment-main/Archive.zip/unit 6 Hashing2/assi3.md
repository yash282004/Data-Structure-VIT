## Assignment 3

WAP to simulate employee databases as a hash table. Search a particular faculty by using Mid square method as a hash function for linear probing method of collision handling technique. Assume suitable data for faculty record.

## Author:
**Pralhad Shivaji Chape**

## Aim:

To write a C++ program to simulate an Employee Database using a Hash Table.
The search operation should be performed using Mid-Square Method as the hash function and Linear Probing as the collision handling technique.

## Problem Statement:

- Create an employee database where each employee record contains:

- Employee ID

- Employee Name

- Employee Salary

- Insert employee records into a hash table using Mid-Square Hash Function.
- If a collision occurs, resolve it using Linear Probing.

- Finally, allow the user to search an employee by ID.

- Hash Function: Mid-Square Method

- Square the key (Employee ID).

-  the middle digits.

- Take modulo by table size if needed.
- Example:
- ID = 123
- 123² = 15129 → middle = 12 → index = 12 % size

## Algorithm
1. Step 1:

- Start the program.

2. Step 2:

- Create a structure Employee with fields:

- id

- name

- salary

3. Step 3:

- Create a hash table array with all entries initialized as empty (-1 ID).

4. Step 4 (Mid-Square Hash Function):

- Compute key²

- Convert to string

- Extract middle 1–2 digits (based on length)

- Index = extracted part % table_size

5. Step 5 (Insert Operation):

- Compute index using mid-square hashing

- If empty → place record

- Else → apply Linear Probing until an empty slot is found

6. Step 6 (Search Operation):

- Compute index using same hash function

- If record matches → return details

- Else probe forward linearly until:

- Key found, or

- Empty slot encountered → record not found

7. Step 7:

- Display output.

8. Step 8:

- Stop.


## C++ Program
```c++
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Employee {
public:
    int id;
    string name;
    float salary;

    Employee() {
        id = -1;
        name = "";
        salary = 0.0;
    }
};

class HashTable {
public:
    int size;
    Employee* table;

    HashTable(int s) {
        size = s;
        table = new Employee[size];
    }

   
    int midSquareHash(int key) {
        long long sq = (long long)key * key;   
        string s = to_string(sq);
        int len = s.length();


        int mid = len / 2;
        string midDigits;

        if (len >= 3)
            midDigits = s.substr(mid - 1, 2); 
        else
            midDigits = s;

        int index = stoi(midDigits) % size;
        return index;
    }


    void insertEmployee(int id, string name, float salary) {
        int index = midSquareHash(id);

     
        int startIndex = index;
        while (table[index].id != -1) {
            index = (index + 1) % size;
            if (index == startIndex) {
                cout << "Hash Table Full! Cannot insert.\n";
                return;
            }
        }

        table[index].id = id;
        table[index].name = name;
        table[index].salary = salary;

        cout << "Inserted at index " << index << endl;
    }


    void searchEmployee(int id) {
        int index = midSquareHash(id);
        int startIndex = index;

        while (table[index].id != -1) {
            if (table[index].id == id) {
                cout << "\nEmployee Found!\n";
                cout << "ID: " << table[index].id << endl;
                cout << "Name: " << table[index].name << endl;
                cout << "Salary: " << table[index].salary << endl;
                return;
            }
            index = (index + 1) % size;
            if (index == startIndex)
                break;
        }

        cout << "\nEmployee NOT FOUND!\n";
    }

    void display() {
        cout << "\nHash Table:\n";
        cout << "Index\tID\tName\tSalary\n";
        for (int i = 0; i < size; i++) {
            cout << i << "\t";
            if (table[i].id != -1)
                cout << table[i].id << "\t" << table[i].name << "\t" << table[i].salary;
            else
                cout << "---";
            cout << endl;
        }
    }
};

int main() {
    cout << "Employee Database Using Mid-Square Hashing + Linear Probing\n";
    cout << "Author: Pralhad Shivaji Chape\n\n";

    int size = 10;
    HashTable _psc(size);

    int n;
    cout << "Enter number of employees to insert: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        int id;
        string name;
        float salary;

        cout << "\nEnter Employee ID: ";
        cin >> id;
        cout << "Enter Name: ";
        cin >> name;
        cout << "Enter Salary: ";
        cin >> salary;

        _psc.insertEmployee(id, name, salary);
    }

    _psc.display();

    int searchId;
    cout << "\nEnter Employee ID to search: ";
    cin >> searchId;

    _psc.searchEmployee(searchId);

    return 0;
}
```

## Sample Output
```
Employee Database Using Mid-Square Hashing + Linear Probing
Author: Pralhad Shivaji Chape

Enter number of employees to insert: 3

Enter Employee ID: 123
Enter Name: Raj
Enter Salary: 45000
Inserted at index 2

Enter Employee ID: 345
Enter Name: Amit
Enter Salary: 55000
Inserted at index 9

Enter Employee ID: 111
Enter Name: Riya
Enter Salary: 60000
Inserted at index 3

Hash Table:
Index   ID    Name   Salary
0       ---
1       ---
2       123   Raj    45000
3       111   Riya   60000
4       ---
5       ---
6       ---
7       ---
8       ---
9       345   Amit   55000

Enter Employee ID to search: 345

Employee Found!
ID: 345
Name: Amit
Salary: 55000
```
## Explanation

- Hashing is done using the mid-square method, ensuring better distribution.

- Collisions are resolved using linear probing.

- Searching uses the same hash function and probing sequence.

- The program simulates a real employee database.