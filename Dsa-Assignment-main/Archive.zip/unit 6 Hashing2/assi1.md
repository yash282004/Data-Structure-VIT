## Assignment 1
*Title:*

WAP to simulate a faculty database as a hash table. Search a particular faculty by using 'divide' as a hash function for linear probing with chaining without replacement method of collision handling technique. Assume suitable data for faculty record.

## Author:
**Pralhad Shivaji Chape**

## Aim:
To write a C++ program to simulate a faculty database using a hash table and search a faculty record using the Divide (modulus) hash function, implementing linear probing with chaining without replacement as the collision resolution technique.

## Problem Statement:
Create a hash table to store faculty records.
Each faculty record contains:

- Faculty ID

- Faculty Name

- Department

Use Divide method: hash(ID) = ID % size
Resolve collisions using Linear Probing with Chaining Without Replacement.
Provide features to:

1. Insert a faculty record

2. Display the hash table

3. Search for a faculty by ID

Assume suitable data.

## Algorithm:
1. Start

2. Define Structure
Create a structure Faculty with:
- id
- name
- dept
- next pointer index

3. Initialize Hash Table
- Create an array of size N
- Set all IDs to -1 (empty)
- Set all next values to -1

4. Hash Function
index = id % size

5. Insertion (Linear Probing + Chaining Without Replacement)
- Compute hash index.
- If the slot is empty → insert.
- Else collision occurs:
- Linearly probe to find an empty slot.
- Insert faculty there.
- Update the chaining link of the original index or its chain.
6. Searching

- Compute hash index.
- Follow the chain using next pointers:
- If ID found → display record.
- If chain ends → record not found.

7. Display
Print table with all fields.
8. Stop

## C++ Program 
```c++
#include <iostream>
#include <string>
using namespace std;

struct Faculty {
    int id;
    string name;
    string dept;
    int next;

    Faculty() {
        id = -1;
        name = "";
        dept = "";
        next = -1;
    }
};

class HashTable {
    int size;
    Faculty *table;

public:
    HashTable(int s) {
        size = s;
        table = new Faculty[size];
    }

    int hashFunction(int id) {
        return id % size;
    }

    void insert(int id, string name, string dept) {
        int index = hashFunction(id);

        if (table[index].id == -1) {
            table[index].id = id;
            table[index].name = name;
            table[index].dept = dept;
            return;
        }

     
        int start = index;
        int emptyIndex = -1;

      
        for (int i = 0; i < size; i++) {
            int probe = (start + i) % size;
            if (table[probe].id == -1) {
                emptyIndex = probe;
                break;
            }
        }

        if (emptyIndex == -1) {
            cout << "\nHash Table is Full!\n";
            return;
        }

      
        table[emptyIndex].id = id;
        table[emptyIndex].name = name;
        table[emptyIndex].dept = dept;

       
        int current = index;
        while (table[current].next != -1)
            current = table[current].next;

        table[current].next = emptyIndex;
    }

    void search(int id) {
        int index = hashFunction(id);
        int current = index;

        while (current != -1) {
            if (table[current].id == id) {
                cout << "\nFaculty Found!\n";
                cout << "ID: " << table[current].id << endl;
                cout << "Name: " << table[current].name << endl;
                cout << "Department: " << table[current].dept << endl;
                return;
            }
            current = table[current].next;
        }

        cout << "\nFaculty Not Found!\n";
    }

    void display() {
        cout << "\nHash Table (Linear Probing + Chaining Without Replacement)\n";
        cout << "Index\tID\tName\tDepartment\tNext\n";
        cout << "-----------------------------------------------------------\n";

        for (int i = 0; i < size; i++) {
            cout << i << "\t";
            cout << table[i].id << "\t";
            cout << table[i].name << "\t";
            cout << table[i].dept << "\t\t";
            cout << table[i].next << endl;
        }
    }
};

int main() {
    cout << "Faculty Database Using Hash Table\n";
    cout << "Author: Pralhad Shivaji Chape\n\n";

    int size = 10;
    HashTable _psc(size);

    int choice;
    do {
        cout << "\n1. Insert Faculty";
        cout << "\n2. Search Faculty";
        cout << "\n3. Display Hash Table";
        cout << "\n4. Exit";
        cout << "\nEnter choice: ";
        cin >> choice;

        if (choice == 1) {
            int id;
            string name, dept;
            cout << "Enter Faculty ID: ";
            cin >> id;
            cout << "Enter Name: ";
            cin >> name;
            cout << "Enter Department: ";
            cin >> dept;

            _psc.insert(id, name, dept);
        }
        else if (choice == 2) {
            int id;
            cout << "Enter Faculty ID to search: ";
            cin >> id;
            _psc.search(id);
        }
        else if (choice == 3) {
            _psc.display();
        }

    } while (choice != 4);

    return 0;
}
```

## Example Output
```
Faculty Database Using Hash Table
Author: Pralhad Shivaji Chape

1. Insert Faculty
2. Search Faculty
3. Display Hash Table
4. Exit
Enter choice: 1
Enter Faculty ID: 105
Enter Name: Rahul
Enter Department: CE

1. Insert Faculty
Enter Faculty ID: 215
Enter Name: Sona
Enter Department: ME

1. Insert Faculty
Enter Faculty ID: 325
Enter Name: Neha
Enter Department: CS

3
Hash Table (Linear Probing + Chaining Without Replacement)
Index   ID   Name   Department   Next
-----------------------------------------------------------
5       105  Rahul  CE           6
6       215  Sona   ME           7
7       325  Neha   CS          -1

2
Enter Faculty ID to search: 215
Faculty Found!
ID: 215
Name: Sona
Department: ME
```

## Explanation

- Hash function: ID % size
- Collisions resolved using:
- Linear Probing
- Chaining without replacement (using next index links)
- Search follows the chain until ID is found or chain ends.
- Works efficiently for faculty database simulation.


