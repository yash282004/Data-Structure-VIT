## Assignment 5
Design and implement a smart college placement portal that uses advanced hashing techniques to efficiently manage student placement records with high performance and low collision probability, even under dynamic data growth.

## Author:
***Pralhad Shivaji Chape***

## Aim

To design and implement a Smart College Placement Portal using advanced hashing (Double Hashing) to efficiently store, search, and manage student placement records while reducing collisions and ensuring high performance even as data grows dynamically.

## Problem Statement

- A college placement cell needs to manage thousands of student records with fields like Roll No, Name, Branch, and Company Placed.
- Traditional linear probing causes high collisions and slow search when the data increases.

- You are required to implement a Smart Placement Portal using:

-  Table

- Advanced Hashing Technique: Double Hashing

- Dynamic Collision Reduction

- Fast Insert, Search, Display, and Delete Functionalities

- The system must support:

- Insert student placement record

- Search student by roll number

- Delete a student record

- Display entire placement database

## Algorithm
1. Start
2. Create a structure Student containing:
- Roll No

- Name

- Branch

- Company

3. Create a Hash Table using an array of Student objects.

- Initialize all positions as empty.

4. Use Double Hashing as a hashing technique:

- Primary hash:

- h1 = roll % TABLE_SIZE

- Secondary hash:

- h2 = 7 - (roll % 7)

5. INSERT Operation

-  index = (h1 + i * h2) % TABLE_SIZE

- If slot is empty → insert

- Else increase i (probing)

6. SEARCH Operation

- Compute index using double hashing

- Probe until found or an empty slot occurs

7. DELETE Operation

- Search using double hashing

- Mark slot as deleted

8. DISPLAY

- Show all filled records in table form.

9. Stop

## C++ Program 
```c++
#include <iostream>
#include <string>
using namespace std;

#define SIZE 20   


class Student {
public:
    int roll;
    string name, branch, company;
    bool occupied;
    bool deleted;

    Student() {
        roll = 0;
        name = branch = company = "";
        occupied = false;
        deleted = false;
    }
};

class PlacementPortal {
private:
    Student table[SIZE];

  
    int h1(int key) {
        return key % SIZE;
    }

    int h2(int key) {
        return 7 - (key % 7);
    }

public:

  
    void insert() {
        Student s;
        cout << "\nEnter Roll No: ";
        cin >> s.roll;
        cout << "Enter Name: ";
        cin >> s.name;
        cout << "Enter Branch: ";
        cin >> s.branch;
        cout << "Enter Company Placed: ";
        cin >> s.company;

        int index = h1(s.roll);
        int step = h2(s.roll);
        int i = 0;

        while (table[(index + i * step) % SIZE].occupied && !table[(index + i * step) % SIZE].deleted) {
            i++;
            if (i == SIZE) {
                cout << "\nHash Table Full! Cannot Insert.\n";
                return;
            }
        }

        int pos = (index + i * step) % SIZE;
        table[pos] = s;
        table[pos].occupied = true;
        table[pos].deleted = false;

        cout << "\nRecord Inserted Successfully!\n";
    }

    void search() {
        int roll;
        cout << "\nEnter Roll No to Search: ";
        cin >> roll;

        int index = h1(roll);
        int step = h2(roll);

        for (int i = 0; i < SIZE; i++) {
            int pos = (index + i * step) % SIZE;

            if (!table[pos].occupied && !table[pos].deleted)
                break;

            if (table[pos].occupied && table[pos].roll == roll) {
                cout << "\nRecord Found:\n";
                cout << "Roll: " << table[pos].roll << "\nName: " << table[pos].name
                     << "\nBranch: " << table[pos].branch
                     << "\nCompany: " << table[pos].company << "\n";
                return;
            }
        }

        cout << "\nRecord NOT Found!\n";
    }


    void remove() {
        int roll;
        cout << "\nEnter Roll No to Delete: ";
        cin >> roll;

        int index = h1(roll);
        int step = h2(roll);

        for (int i = 0; i < SIZE; i++) {
            int pos = (index + i * step) % SIZE;

            if (!table[pos].occupied && !table[pos].deleted)
                break;

            if (table[pos].occupied && table[pos].roll == roll) {
                table[pos].occupied = false;
                table[pos].deleted = true;
                cout << "\nRecord Deleted Successfully!\n";
                return;
            }
        }

        cout << "\nRecord Not Found to Delete!\n";
    }

    void display() {
        cout << "\n----- Smart Placement Portal Database -----\n";
        cout << "Index\tRoll\tName\tBranch\tCompany\n";

        for (int i = 0; i < SIZE; i++) {
            if (table[i].occupied) {
                cout << i << "\t" << table[i].roll << "\t" 
                     << table[i].name << "\t" << table[i].branch 
                     << "\t" << table[i].company << endl;
            }
        }
    }
};

int main() {
    PlacementPortal _psc;
    int choice;

    cout << "SMART COLLEGE PLACEMENT PORTAL USING ADVANCED HASHING\n";
    cout << "Author: Pralhad Shivaji Chape\n";

    while (true) {
        cout << "\nMenu:\n1. Insert Record\n2. Search Record\n3. Delete Record\n4. Display All\n5. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: _psc.insert(); break;
            case 2: _psc.search(); break;
            case 3: _psc.remove(); break;
            case 4: _psc.display(); break;
            case 5: return 0;
            default: cout << "\nInvalid Choice!\n";
        }
    }
}
```

## Sample 
```
SMART COLLEGE PLACEMENT PORTAL USING ADVANCED HASHING
Author: Pralhad Shivaji Chape

Menu:
1. Insert Record
2. Search Record
3. Delete Record
4. Display All
5. Exit
Enter choice: 1

Enter Roll No: 101
Enter Name: Riya
Enter Branch: CSE
Enter Company Placed: Google

Record Inserted Successfully!
```
## Explanation

-  Double Hashing → very low collision rate

- Faster than linear probing

- Supports Insert, Search, Delete, Display

- Works efficiently even when table is nearly full

- Perfect for large growing placement databases