## Assignment 2
*Title:*
WAP to simulate a faculty database as a hash table. Search a particular faculty by using MOD as a hash function for linear probing with chaining with replacement method of collision handling technique. Assume suitable data for faculty record.

## Author:

**Pralhad Shivaji Chape**

## Aim:

To implement a faculty database using a hash table where collision resolution is performed using linear probing with chaining (with replacement) and MOD hash function for searching faculty records.

## Problem Statement:

- Create a hash table to store a faculty database.
- Each faculty record contains:

- Faculty ID (integer)

- Name (string)

- Use hash = FacultyID % TableSize (MOD function).
- If collision occurs, apply linear probing with chaining (with replacement).
- Search for a particular faculty by Faculty ID.

- Assume suitable sample data.

## Algorithm:
1. Start

- Initialize an empty hash table of fixed size (say 10).

2. Hash Function
- hashIndex = facultyID % tableSize

3. Insert Operation (Linear Probing + Chaining With Replacement)

- Compute hash index.

- If slot is empty → insert record.

-  IF slot is filled:

- Check if the current occupant belongs to this slot:

- If NOT (i.e., current record is a displaced record)
→ Swap (Replacement)
- Place new record in correct position, and displaced record will get reinserted using linear probing.

- If belongs → use linear probing to find the next empty slot.
- Record chaining pointer.

4. Search Operation:

- Compute hash index using MOD.

- If record matches → return success.

- If chain exists → follow the chain until record is found.

- If not found → display "Faculty not found".

5. Stop

## C++ Program 
```c++
#include <iostream>
#include <string>
using namespace std;

#define SIZE 10

class Faculty {
public:
    int id;
    string name;
    int chain; 

    Faculty() {
        id = -1;
        name = "";
        chain = -1;
    }
};

class HashTable {
private:
    Faculty table[SIZE];

public:

    int hashFunction(int id) {
        return id % SIZE;
    }

    void insert(int id, string name) {
        int index = hashFunction(id);

        if (table[index].id == -1) {
            table[index].id = id;
            table[index].name = name;
            return;
        }

        int existingIndex = hashFunction(table[index].id);

        if (existingIndex != index) {
       
            int tempID = table[index].id;
            string tempName = table[index].name;
            int tempChain = table[index].chain;

            table[index].id = id;
            table[index].name = name;
            table[index].chain = -1;

    
            insert(tempID, tempName);
        }
        else {
      
            int i = (index + 1) % SIZE;
            while (table[i].id != -1 && i != index)
                i = (i + 1) % SIZE;

            if (i == index) {
                cout << "Hash Table Full!" << endl;
                return;
            }

            table[i].id = id;
            table[i].name = name;

            int temp = index;
            while (table[temp].chain != -1)
                temp = table[temp].chain;

            table[temp].chain = i;
        }
    }

    void search(int id) {
        int index = hashFunction(id);

        if (table[index].id == id) {
            cout << "\nFaculty Found!" << endl;
            cout << "ID: " << table[index].id << ", Name: " << table[index].name << endl;
            return;
        }

        int next = table[index].chain;
        while (next != -1) {
            if (table[next].id == id) {
                cout << "\nFaculty Found!" << endl;
                cout << "ID: " << table[next].id << ", Name: " << table[next].name << endl;
                return;
            }
            next = table[next].chain;
        }

        cout << "\nFaculty NOT Found!" << endl;
    }


    void display() {
        cout << "\nHASH TABLE (MOD + Linear Probing + Chaining WITH Replacement)\n";
        cout << "Index\tID\tName\tChain\n";
        for (int i = 0; i < SIZE; i++) {
            cout << i << "\t" << table[i].id << "\t" << table[i].name << "\t" << table[i].chain << endl;
        }
    }
};

int main() {
    HashTable _psc;
    int choice, id;
    string name;

    cout << "Faculty Database Using Hash Table\n";
    cout << "Author: Pralhad Shivaji Chape\n\n";

    while (true) {
        cout << "\n1. Insert Faculty\n2. Search Faculty\n3. Display Table\n4. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Faculty ID: ";
                cin >> id;
                cout << "Enter Name: ";
                cin >> name;
                _psc.insert(id, name);
                break;

            case 2:
                cout << "Enter Faculty ID to Search: ";
                cin >> id;
                _psc.search(id);
                break;

            case 3:
                _psc.display();
                break;

            case 4:
                return 0;

            default:
                cout << "Invalid Choice!" << endl;
        }
    }
}
```
## Example Output
```
Faculty Database Using Hash Table
Author: Pralhad Shivaji Chape

1. Insert Faculty
Enter Faculty ID: 25
Enter Name: Amit

1. Insert Faculty
Enter Faculty ID: 15
Enter Name: Sneha

1. Insert Faculty
Enter Faculty ID: 35
Enter Name: Rohan

3. Display Table

Index   ID    Name   Chain
0      -1
1      -1
2      -1
3      -1
4      -1
5      25    Amit    7
6      -1
7      15    Sneha   -1
8      -1
9      35    Rohan   -1
```
## Explanation

- MOD hashing maps faculty IDs to table positions.

- When collision happens, linear probing + chaining with replacement is used.

- Replacement ensures that elements are stored as close as possible to their original hash positions.

- Searching follows the chain links for accurate lookups.