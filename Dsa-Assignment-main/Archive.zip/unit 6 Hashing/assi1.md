## Assignment 1

*Title:*
Implement a hash table with collision resolution using linear probing.

## Author:

**Pralhad Shivaji Chape**

## Aim:

To write a C++ program to implement a hash table that stores integer keys.
Collisions must be resolved using Linear Probing while inserting keys.

## Problem Statement:

Create a hash table of user-defined size.
Insert a set of integer keys into the hash table using the hash function:

- hash(key) = key % table_size


If a collision occurs at an index, resolve it using Linear Probing:

- new_index = (index + 1) % table_size


- Your program should:

- - Insert keys into the hash table

- - Handle collisions using linear probing

- - Display the final hash table

## Algorithm:
1. Step 1:

- Start the program.

2. Step 2:

- Input the size of the hash table.

3. Step 3:

- Initialize the hash table with all values set to -1 (meaning empty).

4. Step 4:

- Input number of keys and the keys to insert.

5. Step 5:

- For each key:

- Compute hash index = key % size

- If the calculated index is empty → insert

- Else collision occurs →
- Keep moving forward using

- index = (index + 1) % size


- until an empty slot is found

- Insert the key into the empty position

6. Step 6:

- Display the final hash table.

7. Step 7:

- Stop.

## C++ Program
```cpp
#include <iostream>
#include <vector>
using namespace std;

class HashTable {
private:
    vector<int> table;
    int size;

public:
    HashTable(int s) {
        size = s;
        table.resize(size, -1);  
    }

    void insertKey(int key) {
        int index = key % size;

        int start = index;
        while (table[index] != -1) {
            index = (index + 1) % size;

            if (index == start) {
                cout << "Hash Table is FULL! Cannot insert " << key << endl;
                return;
            }
        }
        table[index] = key;
    }

    void display() {
        cout << "\nFinal Hash Table (Using Linear Probing):\n";
        for (int i = 0; i < size; i++) {
            cout << i << " --> ";
            if (table[i] == -1)
                cout << "EMPTY\n";
            else
                cout << table[i] << "\n";
        }
    }
};

int main() {
    cout << "Hash Table Implementation Using Linear Probing\n";
    cout << "Author: Pralhad Shivaji Chape\n\n";

    int size, n;

    cout << "Enter size of hash table: ";
    cin >> size;

    HashTable _psc(size);

    cout << "Enter number of keys: ";
    cin >> n;

    cout << "Enter " << n << " keys:\n";
    for (int i = 0; i < n; i++) {
        int key;
        cin >> key;
        _psc.insertKey(key);
    }

    _psc.display();

    return 0;
}
```

## Example Output
```
Hash Table Implementation Using Linear Probing
Author: Pralhad Shivaji Chape

Enter size of hash table: 7
Enter number of keys: 5
Enter 5 keys:
10 20 5 15 7

Final Hash Table (Using Linear Probing):
0 --> 7
1 --> 15
2 --> EMPTY
3 --> 10
4 --> 20
5 --> 5
6 --> EMPTY
```

## Explanation:

- The hash table uses the function:

- index = key % size

- If the calculated position is already full, linear probing moves step-by-step to the next index.

- The process continues until an empty slot is found.

- This ensures all keys are stored even if collisions occur.