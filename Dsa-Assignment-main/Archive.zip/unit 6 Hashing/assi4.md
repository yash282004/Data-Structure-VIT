##  Assignment 4

*Title:*
Store and retrieve student records using roll numbers.

## Author:

Pralhad Shivaji Chape

## Aim:

To write a C++ program to implement a hash table to store and retrieve student records, using the **roll number** as the key. Collisions will be resolved using **Separate Chaining (linked lists)**.

## Problem Statement:

Create a hash table of user-defined size to store Student records. Each record must contain a **Roll Number (key)**, **Name**, and **CGPA**.

The program must include the following functionalities:

1.  **Insert Record:** Insert a new student record using the roll number.
2.  **Retrieve Record:** Search for and display a student record given their roll number.
3.  **Display Table:** Display the entire hash table.

Use the hash function:
hash(roll_no) = roll_no % table_size

## Algorithm:
1. Step 1: Define a **Student** structure containing rollNo, name, and cgpa.
2. Step 2: Define the **HashTable** class using a vector of list<Student>.
3. Step 3: Implement the **hashFunction** as rollNo % size.
4. Step 4 (Insert):
    * Compute the index using the roll number.
    * Add the new Student object to the linked list at that index.
5. Step 5 (Retrieve):
    * Compute the index using the roll number.
    * Traverse the linked list at that index.
    * If the record's roll number matches the search key, display the record.
    * If the list is fully traversed without a match, report "Record Not Found."
6. Step 6 (Display): Iterate through all table indices, and for each non-empty linked list, display all student records in the chain.

##  C++ Program
```cpp
#include <iostream>
#include <vector>
#include <list>
#include <string>
#include <iomanip>
#include <limits> 
using namespace std;

struct Student {
    int rollNo;
    string name;
    float cgpa;
};

class HashTable {
private:
    vector<list<Student>> table; 
    int size;

public:
    HashTable(int s) {
        size = s;
        table.resize(size);
    }

    int hashFunction(int rollNo) {
        return rollNo % size;
    }

    void insertRecord(int rollNo, string name, float cgpa) {
        int index = hashFunction(rollNo);
        
        for (const auto& student : table[index]) {
            if (student.rollNo == rollNo) {
                cout << "\nError: Roll Number " << rollNo << " already exists at Index " << index << ".\n";
                return;
            }
        }

        Student newStudent = {rollNo, name, cgpa};
        table[index].push_back(newStudent);
        cout << "\nSuccess: Roll No " << rollNo << " inserted at Index " << index << ".\n";
    }

    void retrieveRecord(int searchRollNo) {
        int index = hashFunction(searchRollNo);
        
        for (const auto& student : table[index]) {
            if (student.rollNo == searchRollNo) {
                cout << "\n--- Record Found (Index " << index << ") ---\n";
                cout << "Roll No: " << student.rollNo << "\n";
                cout << "Name:    " << student.name << "\n";
                cout << "CGPA:    " << fixed << setprecision(2) << student.cgpa << "\n";
                cout << "----------------------------------\n";
                return;
            }
        }
        
        cout << "\nError: Roll Number " << searchRollNo << " not found in Hash Table.\n";
    }

    void display() {
        cout << "\n============================================\n";
        cout << "Final Hash Table (Student Records) - Separate Chaining\n";
        cout << "============================================\n";

        for (int i = 0; i < size; i++) {
            cout << "Index " << i << ": ";
            
            if (table[i].empty()) {
                cout << "EMPTY\n";
            } else {
                for (const auto& student : table[i]) {
                    cout << "(" << student.rollNo << ", " << student.name << ", " << fixed << setprecision(2) << student.cgpa << ") -> ";
                }
                cout << "NULL\n";
            }
        }
        cout << "============================================\n";
    }
};

int main() {
    cout << "Hash Table for Student Records (Separate Chaining)\n";
    cout << "Author: Pralhad Shivaji Chape\n";

    int size;
    cout << "Enter size of the Hash Table: ";

    while (!(cin >> size) || size <= 0) {
        cout << "Invalid input. Enter a positive integer for size: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    HashTable _psc(size); 
    int choice;

    do {
        cout << "\n\n--- MENU ---\n";
        cout << "1. Insert Student Record\n";
        cout << "2. Retrieve Student Record (Search by Roll No)\n";
        cout << "3. Display Hash Table\n";
        cout << "4. Exit\n";
        cout << "Enter your choice (1-4): ";
        
        if (!(cin >> choice)) {
            cout << "\nInvalid input. Please enter a number (1-4).\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1: {
                int rollNo;
                string name;
                float cgpa;

                cout << "\n-- INSERT RECORD --\n";
                cout << "Enter Roll Number: ";
                if (!(cin >> rollNo)) break;
                
                cout << "Enter Name: ";
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
                getline(cin, name);

                cout << "Enter CGPA: ";
                if (!(cin >> cgpa)) break;
                
           
                _psc.insertRecord(rollNo, name, cgpa); 
                break;
            }
            case 2: {
                int searchRollNo;
                cout << "\n-- RETRIEVE RECORD --\n";
                cout << "Enter Roll Number to search: ";
                if (!(cin >> searchRollNo)) break;
                
       
                _psc.retrieveRecord(searchRollNo); 
                break;
            }
            case 3: {
          
                _psc.display(); 
                break;
            }
            case 4: {
                cout << "\nExiting program. Goodbye!\n";
                break;
            }
            default: {
                cout << "\nInvalid choice. Please enter a number between 1 and 4.\n";
            }
        }
        
        if (cin.fail()) {
            cout << "\nInvalid input format detected. Returning to menu.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

    } while (choice != 4);

    return 0;
}
```
## output
```
Hash Table for Student Records (Separate Chaining)
Author: Pralhad Shivaji Chape
Enter size of the Hash Table: 5


--- MENU ---
1. Insert Student Record
2. Retrieve Student Record (Search by Roll No)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 1

-- INSERT RECORD --
Enter Roll Number: 10
Enter Name: Mark
Enter CGPA: 9.0
Success: Roll No 10 inserted at Index 0.


--- MENU ---
1. Insert Student Record
2. Retrieve Student Record (Search by Roll No)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 1

-- INSERT RECORD --
Enter Roll Number: 15
Enter Name: Sarah
Enter CGPA: 8.5
Success: Roll No 15 inserted at Index 0.


--- MENU ---
1. Insert Student Record
2. Retrieve Student Record (Search by Roll No)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 1

-- INSERT RECORD --
Enter Roll Number: 22
Enter Name: Tom
Enter CGPA: 7.9
Success: Roll No 22 inserted at Index 2.


--- MENU ---
1. Insert Student Record
2. Retrieve Student Record (Search by Roll No)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 2

-- RETRIEVE RECORD --
Enter Roll Number to search: 15

--- Record Found (Index 0) ---
Roll No: 15
Name:    Sarah
CGPA:    8.50
----------------------------------


--- MENU ---
1. Insert Student Record
2. Retrieve Student Record (Search by Roll No)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 3

============================================
Final Hash Table (Student Records) - Separate Chaining
============================================
Index 0: (10, Mark, 9.00) -> (15, Sarah, 8.50) -> NULL
Index 1: EMPTY
Index 2: (22, Tom, 7.90) -> NULL
Index 3: EMPTY
Index 4: EMPTY
============================================


--- MENU ---
1. Insert Student Record
2. Retrieve Student Record (Search by Roll No)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 4

Exiting program. Goodbye!
```

## Explanation:
- Student Structure: A struct Student is used to group the related data (roll number, name, cgpa) into a single record.

- Data Storage: The hash table is implemented as a vector<list<Student>>. The primary vector provides O(1) access to the index (bucket), and the linked list (std::list<Student>) within each bucket stores the full records.

- Insertion: To insert a record, the roll number is hashed to find the bucket index. The entire Student object is then added to the list at that index.

- Retrieval: To retrieve a record, the target roll number is hashed to find the correct index. The program then performs a linear search only on the short linked list (the chain) at that specific index. This keeps the retrieval process very fast, even when collisions occur.