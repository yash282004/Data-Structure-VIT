## Assignment 2

*Title:*
Implement a hash table with collision resolution using separate chaining.

## Author:

Pralhad Shivaji Chape

## Aim:

To write a C++ program to implement a hash table that stores integer keys.
Collisions must be resolved using Separate Chaining by using a linked list at each bucket.

## Problem Statement:

Create a hash table of user-defined size.
Insert a set of integer keys into the hash table using the hash function:

- hash(key) = key % table_size

If a collision occurs at an index, resolve it using Separate Chaining by appending the key to the linked list (chain) at that bucket.

Your program should:

* Insert keys into the hash table.
* Handle collisions using separate chaining.
* Display the final hash table, showing the chain (linked list) at each index.

## Algorithm:
1. Step 1: Start the program.
2. Step 2: Input the size of the hash table.
3. Step 3: Initialize the hash table as an array of lists (or vectors), where each element (bucket) is an empty list/chain.
4. Step 4: Input the number of keys and the keys to insert.
5. Step 5: For each key:
    * Compute the hash index = key % size.
    * Go to the calculated index (bucket) in the hash table array.
    * Append the key to the end of the list (chain) present at that index.
6. Step 6: Display the final hash table, iterating through each index and printing all keys stored in the corresponding list (chain).
7. Step 7: Stop.

## C++ Program
```cpp
#include <iostream>
#include <vector>
#include <list>
using namespace std;

class HashTable {
private:
   
    vector<list<int>> table;
    int size;

public:
    HashTable(int s) {
        size = s;
       
        table.resize(size);
    }


    int hashFunction(int key) {
        return key % size;
    }

    void insertKey(int key) {
        int index = hashFunction(key);
    
        table[index].push_back(key);
        cout << "Inserted " << key << " at index " << index << " (Chain)\n";
    }

    void display() {
        cout << "\nFinal Hash Table (Using Separate Chaining):\n";
        for (int i = 0; i < size; i++) {
            cout << "Index " << i << ": ";
            
     
            if (table[i].empty()) {
                cout << "EMPTY";
            } else {
                for (int key : table[i]) {
                    cout << key << " -> ";
                }
           
                cout << "NULL"; 
            }
            cout << "\n";
        }
    }
};

int main() {
    cout << "Hash Table Implementation Using Separate Chaining\n";
    cout << "Author: Pralhad Shivaji Chape\n\n";

    int size, n;

    cout << "Enter size of hash table: ";
    cin >> size;

    HashTable _psc(size);

    cout << "Enter number of keys: ";
    cin >> n;

    cout << "Enter " << n << " keys:\n";
    for (int i = 0; i < n; i++) {
        int key;
        cin >> key;
        _psc.insertKey(key);
    }

    _psc.display();

    return 0;
}
```
## Example Output
```
For keys 10, 24, 3, 17, 31 with a table size of 7.

Hash Table Implementation Using Separate Chaining
Author: Pralhad Shivaji Chape

Enter size of hash table: 7
Enter number of keys: 5
Enter 5 keys:
10
Inserted 10 at index 3 (Chain)
24
Inserted 24 at index 3 (Chain)
3
Inserted 3 at index 3 (Chain)
17
Inserted 17 at index 3 (Chain)
31
Inserted 31 at index 3 (Chain)

Final Hash Table (Using Separate Chaining):
Index 0: EMPTY
Index 1: EMPTY
Index 2: EMPTY
Index 3: 10 -> 24 -> 3 -> 17 -> 31 -> NULL
Index 4: EMPTY
Index 5: EMPTY
Index 6: EMPTY
```
## Explanation:
- Structure: The hash table is implemented as a vector of linked lists (std::list).

- Hashing: All five keys (10, 24, 3, 17, 31) hash to the same index: 3 (since k % 7 = 3).

- Collision Handling: Instead of finding the next empty slot (like Linear Probing), Separate Chaining adds all colliding keys to the list at index 3. The chain visually represents how multiple data items can reside in the same bucket.