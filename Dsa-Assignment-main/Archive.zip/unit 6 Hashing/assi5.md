## Assignment 5
*Title:*
WAP to simulate a faculty database as a hash table. Search a particular faculty by using MOD as a hash function for linear probing method of collision handling technique. Assume suitable data for faculty record.

## Author:
**Pralhad Shivaji Chape**

## Aim:
To write a C++ program to simulate a faculty database as a hash table. The program will store and retrieve Faculty Records using an ID as the key. Collisions will be resolved using Linear Probing.

## Problem Statement:
- Create a hash table of user-defined size to store Faculty records. Assume each record contains a Faculty ID (key), Name, and Department.

- The program must include the following functionalities:

- Insert Record: Insert a new faculty record using the Faculty ID.

- Search Record: Search for and display a faculty record given their Faculty ID, using the linear probing sequence if a collision occurred during insertion.

- Display Table: Display the entire hash table.

- Use the hash function: hash(Faculty_ID) = Faculty_ID % table_size

## Algorithm:
1. Step 1: Define a Faculty structure containing facultyID, name, and department. Use 0 to mark an empty slot.

2. Step 2: Define the HashTable class using a vector<Faculty>.

3. Step 3: Implement the hashFunction as Faculty_ID % size.

4. Step 4 (Insert):

- Compute the initial hash index.

- Linear Probing: If the slot is occupied, probe for the next slot using: new_index = (index + 1) % size. Repeat until an empty slot is found or the table is full.

5. Step 5 (Search):

- Compute the initial hash index.

- Search Sequence: Probe using new_index = (index + 1) % size. Stop if the key is found, an empty slot is encountered (record is not found), or the probe returns to the start (table searched).

6. Step 6 (Display): Iterate through the table and display all stored faculty records.

## C++ Program
```cpp
#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include <iomanip>
using namespace std;


const int EMPTY_SLOT = 0; 

struct Faculty {
    int facultyID = EMPTY_SLOT;
    string name = "";
    string department = "";
};

class HashTable {
private:
    vector<Faculty> table;
    int size;

public:
    HashTable(int s) {
        size = s;
        table.resize(size);
    }

    int hashFunction(int id) {
        return id % size;
    }

    void insertRecord(int id, string name, string dept) {
        if (id <= EMPTY_SLOT) {
            cout << "\nError: Faculty ID must be a positive integer.\n";
            return;
        }
        
        int index = hashFunction(id);
        int start = index;

        while (table[index].facultyID != EMPTY_SLOT) {
            
            if (table[index].facultyID == id) {
                 cout << "\nError: Faculty ID " << id << " already exists at Index " << index << ".\n";
                 return;
            }

            index = (index + 1) % size;

            if (index == start) {
                cout << "\nError: Hash Table is FULL! Cannot insert Faculty ID " << id << ".\n";
                return;
            }
        }
        
        table[index].facultyID = id;
        table[index].name = name;
        table[index].department = dept;
        cout << "\nSuccess: Faculty ID " << id << " inserted at Index " << index << ".\n";
    }


    void searchRecord(int searchID) {
        if (searchID <= EMPTY_SLOT) {
            cout << "\nError: Invalid search ID.\n";
            return;
        }

        int index = hashFunction(searchID);
        int start = index;

        while (table[index].facultyID != EMPTY_SLOT) {
            if (table[index].facultyID == searchID) {
            
                cout << "\n--- Record Found (Index " << index << ") ---\n";
                cout << "Faculty ID:  " << table[index].facultyID << "\n";
                cout << "Name:        " << table[index].name << "\n";
                cout << "Department:  " << table[index].department << "\n";
                cout << "----------------------------------\n";
                return;
            }

            index = (index + 1) % size;

            if (index == start) {
                break; 
            }
        }
        
        cout << "\nError: Faculty ID " << searchID << " not found in Hash Table.\n";
    }


    void display() {
        cout << "\n============================================\n";
        cout << "Faculty Database (Linear Probing)\n";
        cout << "============================================\n";

        for (int i = 0; i < size; i++) {
            cout << "Index " << i << ": ";
            
            if (table[i].facultyID == EMPTY_SLOT) {
                cout << "EMPTY\n";
            } else {
                cout << table[i].facultyID << " - " << table[i].name << " (" << table[i].department << ")\n";
            }
        }
        cout << "============================================\n";
    }
};

int main() {
    cout << "Faculty Database Hash Table (Linear Probing)\n";
    cout << "Author: Pralhad Shivaji Chape\n";

    int size;
    cout << "Enter size of the Hash Table: ";

    while (!(cin >> size) || size <= 0) {
        cout << "Invalid input. Enter a positive integer for size: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }


    HashTable _psc(size);
    int choice;

    do {
        cout << "\n\n--- MENU ---\n";
        cout << "1. Insert Faculty Record\n";
        cout << "2. Search Faculty Record (Search by ID)\n";
        cout << "3. Display Hash Table\n";
        cout << "4. Exit\n";
        cout << "Enter your choice (1-4): ";
        

        if (!(cin >> choice)) {
            cout << "\nInvalid input. Please enter a number (1-4).\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1: {
                int id;
                string name;
                string dept;

                cout << "\n-- INSERT RECORD --\n";
                cout << "Enter Faculty ID (e.g., 101, 11, 21): ";
                if (!(cin >> id)) break;
                
                cout << "Enter Name: ";
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
                getline(cin, name);

                cout << "Enter Department: ";
                getline(cin, dept);
         
                _psc.insertRecord(id, name, dept);
                break;
            }
            case 2: {
                int searchID;
                cout << "\n-- SEARCH RECORD --\n";
                cout << "Enter Faculty ID to search: ";
                if (!(cin >> searchID)) break;
              
                _psc.searchRecord(searchID);
                break;
            }
            case 3: {
              
                _psc.display();
                break;
            }
            case 4: {
                cout << "\nExiting program. Goodbye!\n";
                break;
            }
            default: {
                cout << "\nInvalid choice. Please enter a number between 1 and 4.\n";
            }
        }
        
        if (cin.fail()) {
            cout << "\nInvalid input format detected. Returning to menu.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

    } while (choice != 4);

    return 0;
}
```
## Example Output (Demonstrating Linear Probing)
```
Assuming the user enters a Hash Table Size of 10 and inserts the IDs 101, 11, 21, 105, 5.

Faculty Database Hash Table (Linear Probing)
Author: Pralhad Shivaji Chape
Enter size of the Hash Table: 10

--- MENU ---
1. Insert Faculty Record
2. Search Faculty Record (Search by ID)
3. Display Hash Table
4. Exit
Enter your choice (1-4): 1

-- INSERT RECORD --
Enter Faculty ID (e.g., 101, 11, 21): 101
Enter Name: Mark
Enter Department: CSE
Success: Faculty ID 101 inserted at Index 1.

--- MENU ---
... (user selects 1 again)
-- INSERT RECORD --
Enter Faculty ID (e.g., 101, 11, 21): 11
Enter Name: Sarah
Enter Department: ECE
Success: Faculty ID 11 inserted at Index 2.

--- MENU ---
... (user selects 1 again)
-- INSERT RECORD --
Enter Faculty ID (e.g., 101, 11, 21): 21
Enter Name: Tom
Enter Department: ECE
Success: Faculty ID 21 inserted at Index 3.

--- MENU ---
... (user selects 3)

============================================
Faculty Database (Linear Probing)
============================================
Index 0: EMPTY
Index 1: 101 - Mark (CSE)
Index 2: 11 - Sarah (ECE)
Index 3: 21 - Tom (ECE)
Index 4: EMPTY
Index 5: 105 - David (ME)
Index 6: 5 - Eve (ME)
Index 7: EMPTY
Index 8: EMPTY
Index 9: EMPTY
============================================

--- MENU ---
... (user selects 2)
-- SEARCH RECORD --
Enter Faculty ID to search: 21

--- Record Found (Index 3) ---
Faculty ID:  21
Name:        Tom
Department:  ECE
----------------------------------
```
## Explanation:
- Record Structure: The struct Faculty holds the record fields: facultyID (the key), name, and department. The facultyID = 0 is used to clearly mark an empty slot.
- Linear Probing (Insertion): When inserting keys like 101, 11, and 21, which all initially hash to Index 1 
(since $101, 11, 21 \pmod{10} = 1$)

1. 11 collides at Index 1 and probes to the next available slot, Index 
2. 21 collides at Index 1 and Index 2, and probes to the next available slot, Index 3 This demonstrates the Primary Clustering effect inherent in Linear Probing.

- Linear Probing (Search): When searching for ID 21, the search starts at the initial hash Index 1. It finds 101 (no match), probes to Index 2 (finds 11, no match), and finally probes to Index 3 where 21 is found. The search successfully retraces the exact collision path.